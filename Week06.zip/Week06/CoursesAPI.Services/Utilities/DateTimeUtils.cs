﻿namespace CoursesAPI.Services.Utilities
{
	public class DateTimeUtils
	{
		public static bool IsLeapYear(int year)
		{
			// TODO: implement!
			return false;
		}
	}
}
